1. Nous devons utiliser un serveur pour envoyer des fichier � un serveur

2. Pour r�sourder ce prol�me, nous devons creer un programme qui initialise 
	un fichier null. Au moment de l'envoi par le client, le fichier pass� en param�tre sera
	affect� ) notre fichier d'envoi qui sera transf�r� vers le serveur.

3. (Impl�mentation)
