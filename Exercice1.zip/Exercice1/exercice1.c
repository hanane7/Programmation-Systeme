// Auteur YAYA Hanane

#include <unistd.h> 
#include <stdio.h> 
#include <sys/types.h> 
int main() 
{
 
    pid_t pid1 = fork();
    if (pid1 == 0)
      {
 	 printf("Le pid du premier fils est (%d)\n", getpid()); 
	 return 0;
      }
    pid_t pid2 = fork();
    if (pid2 == 0)
      {
 	 printf("Le pid du second fils est (%d)\n", getpid()); 
	 return 0;
      }
    pid_t pid3 = fork();
    if (pid3 == 0)
      { 
         printf("Le pid du troisieme fils est (%d)\n", getpid()); 
	 return 0;
      }
   
    return 0;
 }
