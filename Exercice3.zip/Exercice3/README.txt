1-Les problemes � resoudre ici sont :
*chaque processus qui calcule un cij doit acc�der � la matrice en m�moire partag�e
*les processus doivent s'ex�cuter dans un ordre pr�cis
*initialisation de la matrice 
*le stockage du r�sultat de chaque processus apr�s traitement 
*remplissage des valeurs entr�es par l'utilisateur dans la matrice

2-Pour r�soudre nos probl�mes , nous envoyons au programme un fichier contenant la matrice. On lit l'ordre de la matrice puis on cr�e un tableau dynamique qui doit prendre les valeurs de la matrice .
On cr�e ensuite des processus qui devront contenir chaque cij.
Lorsqu'un cij est pris pour un calcul, on met un marqueur -1 pour signifier qu'il a ete pris.

3 - Impl�mentation
